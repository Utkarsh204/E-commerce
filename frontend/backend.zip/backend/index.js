const express = require("express");
const mongoose = require("mongoose");
const jwt = require("jsonwebtoken");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const cors = require("cors");

const app = express();
const port = process.env.PORT || 4000;

// ✅ Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());

// ✅ Ensure Upload Directory Exists
const uploadDir = path.join(__dirname, "upload/images");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// ✅ Multer Setup
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const uniqueName = `product_${Date.now()}${path.extname(file.originalname)}`;
    cb(null, uniqueName);
  },
});
const upload = multer({ storage });

// ✅ Serve Uploaded Images
app.use("/images", express.static(uploadDir));

// ✅ MongoDB Connection
mongoose
  .connect("mongodb+srv://greatstackdev:9012255766@cluster0.0yjtsd2.mongodb.net/e-commerce")
  .then(() => console.log("✅ Connected to MongoDB"))
  .catch((err) => console.error("❌ MongoDB Connection Error:", err));

// ✅ Product Schema
const Product = mongoose.model("Product", {
  id: { type: Number, required: true },
  name: { type: String, required: true },
  image: { type: String, required: true },
  category: { type: String, required: true },
  new_price: { type: Number, required: true },
  old_price: { type: Number, required: true },
  date: { type: Date, default: Date.now },
  avilable: { type: Boolean, default: true },
});

// ✅ Upload Image Route
app.post("/upload", upload.single("product"), (req, res) => {
  if (!req.file) {
    console.error("❌ No file uploaded");
    return res.status(400).json({ success: false, message: "No file uploaded" });
  }

  const imageUrl = `http://localhost:${port}/images/${req.file.filename}`;
  console.log("✅ Image uploaded:", imageUrl);
  res.json({ success: true, image_url: imageUrl });
});

//Shema for create for user products

const Users = mongoose.model('Users', {
  name: { type: String },
  email: { type: String },
  password: { type: String },
  cartData: { type: Object },
  date: { type: Date, default: Date.now },
});

// Signup route
app.post('/signup', async (req, res) => {
  let check = await Users.findOne({ email: req.body.email });
  if (check) {
    return res.status(400).json({ success: false, errors: "Existing user found with same email address" });
  }

  let cart = {};
  for (let i = 0; i < 300; i++) {
    cart[i] = 0;
  }

  const user = new Users({
    name: req.body.username,
    email: req.body.email,
    password: req.body.password,
    cartData: cart,
  });

  await user.save();

  const data = {
    user: {
      id: user.id,
    }
  };

  const token = jwt.sign(data, 'secret_ecom'); // ✅ Signing JWT token
  res.json({ success: true, token });
});

//Creating Endpoint for user login
app.post('/login', async (req, res) => {
  let user = await Users.findOne({ email: req.body.email });
  if (user) {
      const passCompare = req.body.password === user.password;
      if (passCompare) {
        const data = {
          user: {
            id: user.id,
          }
        }
       const token = jwt.sign(data, 'secret_ecom'); // ✅ Signing JWT token
       res.json({ success: true, token });

      }
      else{
        res.json({ success: false, errors: "Wrong Password" });
      }
  }
  else{
    res.json({ success: false, errors: "Wrong email id" });
  }

})


// creating endpoint for getting newcollection data
app.get('/newcollections', async (req, res) => {
     let products = await Product.find({});
     let newcollection = products.slice(1).slice(-8);
     console.log("NewCollection fetched");
      res.send(newcollection);
})
// creating endpoint for getting in women section
app.get('/popularinwomen', async (req, res) => {
  let products = await Product.find({ category:"women"});
  let popular_in_women =products.slice(0,4);
  console.log("popular in women fetched");
  res.send(popular_in_women);

})
// creating middleware to fetch user

const fetchUser = (req, res, next) => {
  const token = req.header('auth-token');
  if (!token) {
    return res.status(401).send({ error: "Please authenticate using a valid token" });
  }
  else{
  try {
    const data = jwt.verify(token, 'secret_ecom');
    req.user = data.user;
    next();
  }catch (error) {
    return res.status(401).send({ error: "Please authenticate using a valid token" });
  }
}

}

// creating endpoint for adding products in cartdata
app.post('/addtocart', fetchUser, async (req, res) => {
  console.log("added",req.body.itemId);
  let userData = await Users.findOne({_id: req.user.id});
  userData.cartData[req.body.itemId] += 1;
  await Users.findOneAndUpdate({_id: req.user.id}, {cartData: userData.cartData});
  res.send("Added")

})
// creating endpoint to remove products from cartdata
app.post('/removefromcart', fetchUser, async (req, res) => {
  console.log("removed",req.body.itemId);
  let userData = await Users.findOne({_id: req.user.id});
  if(userData.cartData[req.body.itemId]>0) 
   userData.cartData[req.body.itemId] -= 1;
  await Users.findOneAndUpdate({_id: req.user.id}, {cartData: userData.cartData});
  res.send("Removed")

})
//creating endpoint to get cartdata
app.post('/getcart',fetchUser,async (req,res)=>{
  console.log("GetCart");
  let userData = await Users.findOne({_id: req.user.id})
  res.json(userData.cartData);


})

// ✅ Add Product Route
app.post("/addproduct", async (req, res) => {
  try {
    let products = await Product.find({});
    let id = products.length > 0 ? products[products.length - 1].id + 1 : 1;

    if (!req.body.image) {
      return res.status(400).json({ success: false, message: "Image URL is missing" });
    }

    const product = new Product({
      id,
      name: req.body.name,
      image: req.body.image,
      category: req.body.category,
      new_price: req.body.new_price,
      old_price: req.body.old_price,
    });

    await product.save();
    console.log("✅ Product saved:", product.name);

    res.json({ success: true, name: product.name });
  } catch (error) {
    console.error("❌ Error saving product:", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

// ✅ Remove Product Route
app.post('/removeproduct', async (req, res) => {
  try {
    console.log("🗑️ Trying to remove:", req.body._id);
    await Product.findByIdAndDelete(req.body._id); // 🔥 this line fixed it!
    console.log("✅ Removed:", req.body._id);
    res.json({ success: true });
  } catch (err) {
    console.error("❌ Error removing product:", err);
    res.status(500).json({ success: false, message: "Failed to remove product" });
  }
});
// ✅ Get All Products Route
app.get("/allproducts", async (req, res) => {
  try {
    const products = await Product.find({});
    console.log("📦 All products fetched:", products.length);
    res.json(products);
  } catch (err) {
    console.error("❌ Error fetching products:", err);
    res.status(500).json({ success: false, message: "Fetch failed" });
  }
});

// ✅ Home Route
app.get("/", (req, res) => {
  res.send("🚀 Express App is Running!");
});

// ✅ Start Server
app.listen(port, () => {
  console.log(`🚀 Server is running on http://localhost:${port}`);
});
